function Button() {
  return (
    <>
    <button className="main_wrap_button">READ MORE</button>
    </>
  )
}

export default Button